@usableFromInline
enum GraphContentEffect {}
